import streamlit as st
import pandas as pd
from datetime import datetime, date
import openpyxl
import io
import re

# ─────────────────────────────────────────────────────────────────────────────
# PAGE CONFIG
# ─────────────────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Trailer Status Dashboard",
    page_icon="🚛",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─────────────────────────────────────────────────────────────────────────────
# CUSTOM CSS
# ─────────────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
    /* Main background */
    .main { background-color: #f0f2f6; }

    /* Header */
    .dashboard-header {
        background: linear-gradient(135deg, #1e3a5f 0%, #2563a8 100%);
        color: white;
        padding: 24px 32px;
        border-radius: 12px;
        margin-bottom: 24px;
        box-shadow: 0 4px 16px rgba(30,58,95,0.18);
    }
    .dashboard-header h1 { margin: 0; font-size: 2rem; font-weight: 700; letter-spacing: 1px; }
    .dashboard-header p  { margin: 4px 0 0; opacity: .75; font-size: .95rem; }

    /* Status badges */
    .badge {
        display: inline-block;
        padding: 4px 14px;
        border-radius: 20px;
        font-size: .82rem;
        font-weight: 700;
        letter-spacing: .5px;
    }
    .badge-vor      { background:#fee2e2; color:#991b1b; }
    .badge-depot    { background:#dbeafe; color:#1e40af; }
    .badge-parking  { background:#fef9c3; color:#854d0e; }
    .badge-onroad   { background:#dcfce7; color:#166534; }
    .badge-dispose  { background:#f3e8ff; color:#6b21a8; }
    .badge-na       { background:#f3f4f6; color:#6b7280; }

    /* Metric card */
    .metric-card {
        background: white;
        border-radius: 10px;
        padding: 18px 20px;
        text-align: center;
        box-shadow: 0 2px 8px rgba(0,0,0,.07);
        border-top: 4px solid;
    }
    .metric-card .val  { font-size: 2.2rem; font-weight: 800; }
    .metric-card .lbl  { font-size: .8rem;  color: #6b7280; margin-top: 2px; }

    /* Table styling via st.dataframe is limited; we tweak via st.markdown table */
    .status-table th {
        background-color: #1e3a5f !important;
        color: white !important;
        font-size: .85rem;
        padding: 10px 14px;
    }
    .status-table td { font-size: .83rem; padding: 8px 14px; }
    .status-table tr:nth-child(even) { background-color: #f8fafc; }

    /* Upload panel */
    .upload-box {
        background: white;
        border-radius: 10px;
        padding: 20px;
        margin-bottom: 16px;
        border: 1px solid #e2e8f0;
        box-shadow: 0 1px 4px rgba(0,0,0,.05);
    }
    .upload-box h4 { margin: 0 0 8px; color: #1e3a5f; font-size: .95rem; }

    /* Divider */
    hr { border-top: 1px solid #e2e8f0; margin: 20px 0; }
</style>
""", unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def normalize(val):
    """Strip & uppercase a cell value for comparison."""
    if pd.isna(val):
        return ""
    return str(val).strip().upper()


def read_excel_bytes(uploaded_file):
    """Return openpyxl Workbook from an uploaded file."""
    return openpyxl.load_workbook(io.BytesIO(uploaded_file.read()), data_only=True)


def df_from_sheet(wb, sheet_name, header_row=0):
    """Convert a worksheet to a DataFrame."""
    ws = wb[sheet_name]
    data = list(ws.values)
    if not data:
        return pd.DataFrame()
    # find first non-empty row as header if header_row == 0
    cols = [str(c) if c is not None else "" for c in data[header_row]]
    rows = data[header_row + 1:]
    return pd.DataFrame(rows, columns=cols)


def find_header_row(ws, target_col_keyword, max_rows=15):
    """Scan rows to find the row index (0-based) containing target_col_keyword."""
    for i, row in enumerate(ws.iter_rows(max_row=max_rows, values_only=True)):
        for cell in row:
            if cell and target_col_keyword.upper() in str(cell).upper():
                return i
    return 0


def sheet_df(wb, sheet_name, keyword="Fleet"):
    """Smart load: detect header row by keyword."""
    ws = wb[sheet_name]
    hdr = find_header_row(ws, keyword)
    data = list(ws.values)
    if not data or hdr >= len(data):
        return pd.DataFrame()
    cols = [str(c).strip() if c is not None else "" for c in data[hdr]]
    rows = data[hdr + 1:]
    return pd.DataFrame(rows, columns=cols)


def find_col(df, candidates):
    """Return first column name in df that matches any candidate (case-insensitive)."""
    for c in candidates:
        for col in df.columns:
            if c.upper() in col.upper():
                return col
    return None


def is_date_pattern_sheet(name):
    """Return True if sheet name looks like a date, e.g. '10 Jun 26', '11 May 25'."""
    months = ["jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"]
    lower = name.lower()
    return any(m in lower for m in months) and any(c.isdigit() for c in lower)


def badge_html(status):
    """Return coloured HTML badge for a status string."""
    s = status.strip().upper()
    if s == "VOR":
        return f'<span class="badge badge-vor">⚠️ VOR</span>'
    elif s.startswith("PARKING"):
        return f'<span class="badge badge-parking">🅿️ {status}</span>'
    elif s == "ON ROAD":
        return f'<span class="badge badge-onroad">🚛 On Road</span>'
    elif s == "DISPOSE":
        return f'<span class="badge badge-dispose">🗑️ Dispose</span>'
    elif s == "N/A":
        return f'<span class="badge badge-na">— N/A</span>'
    else:
        return f'<span class="badge badge-depot">🏭 {status}</span>'


# ─────────────────────────────────────────────────────────────────────────────
# CORE LOGIC
# ─────────────────────────────────────────────────────────────────────────────

def get_status_for_trailer(fleet_no, wb_vor_all, wb_vor_lin, wb_trucker, today):
    fn = normalize(fleet_no)
    if not fn:
        return "N/A"

    # ── Step 1 : VOR Allnow ──────────────────────────────────────────────────
    # 1a) ทุก sheet ยกเว้น "รอขาย" → VOR
    for sname in wb_vor_all.sheetnames:
        if "รอขาย" in sname:
            continue
        df = sheet_df(wb_vor_all, sname, "Fleet")
        col = find_col(df, ["Fleet No", "Fleet#", "Fleet Number", "Trailer"])
        if col is None:
            continue
        if fn in df[col].map(normalize).values:
            return "VOR"

    # 1b) sheet "รอขาย" → Dispose
    for sname in wb_vor_all.sheetnames:
        if "รอขาย" not in sname:
            continue
        df = sheet_df(wb_vor_all, sname, "Fleet")
        col = find_col(df, ["Fleet No", "Fleet#", "Fleet Number", "Trailer"])
        if col is None:
            continue
        if fn in df[col].map(normalize).values:
            return "Dispose"

    # ── Step 2 : VOR Linfox ─────────────────────────────────────────────────
    # 2a) sheet ชื่อวันที่ เช่น "10 Jun 26" → VOR
    date_sheets = [s for s in wb_vor_lin.sheetnames if is_date_pattern_sheet(s)]
    for sname in date_sheets:
        df = sheet_df(wb_vor_lin, sname, "Fleet")
        col = find_col(df, ["Fleet No", "Fleet#", "Fleet Number", "Trailer"])
        if col is None:
            continue
        if fn in df[col].map(normalize).values:
            return "VOR"

    # 2b) sheet "Disposal Status" → Dispose
    for sname in wb_vor_lin.sheetnames:
        if "disposal" not in sname.lower():
            continue
        df = sheet_df(wb_vor_lin, sname, "Fleet")
        col = find_col(df, ["Fleet No", "Fleet#", "Fleet Number", "Trailer"])
        if col is None:
            continue
        if fn in df[col].map(normalize).values:
            return "Dispose"

    # ── Step 3 : Trucker ────────────────────────────────────────────────────
    # Combine all sheets, keep row order, then reverse (bottom-up)
    trucker_frames = []
    for sname in wb_trucker.sheetnames:
        df = sheet_df(wb_trucker, sname, "Trailer")
        if df.empty:
            continue
        df["_sheet"] = sname
        trucker_frames.append(df)
    if trucker_frames:
        trucker_df = pd.concat(trucker_frames, ignore_index=True)
        trailer_col = find_col(trucker_df, ["Trailer"])
        depart_col  = find_col(trucker_df, ["Depart Depot", "Depot"])
        conf_dep    = find_col(trucker_df, ["Confirmed Depart DC", "Confirmed Depart"])
        conf_ret    = find_col(trucker_df, ["Confirmed Return DC", "Confirmed Return"])

        if trailer_col:
            matched = trucker_df[trucker_df[trailer_col].map(normalize) == fn]
            # Bottom-up = last occurrence first
            matched = matched.iloc[::-1]

            for _, row in matched.iterrows():
                depot = str(row[depart_col]).strip() if depart_col and not pd.isna(row[depart_col]) else ""

                dep_time = row[conf_dep] if conf_dep else None
                ret_time = row[conf_ret] if conf_ret else None

                # Parse depart date — robust against datetime objects, strings, NaT
                dep_date = None
                try:
                    if dep_time is not None and str(dep_time).strip() not in ("", "NaT", "None", "nan"):
                        dep_date = pd.to_datetime(dep_time, dayfirst=True, errors="coerce")
                        if pd.notna(dep_date):
                            dep_date = dep_date.date()
                        else:
                            dep_date = None
                except Exception:
                    dep_date = None

                has_return = (
                    ret_time is not None
                    and str(ret_time).strip() not in ("", "NaT", "None", "nan")
                    and pd.notna(pd.to_datetime(ret_time, errors="coerce"))
                )

                # 3.1 – depart today, no return → ชื่อ Depart Depot
                if dep_date == today and not has_return:
                    return depot if depot else "Unknown Depot"

                # 3.2 – not today, has return → Parking + Depot
                if dep_date is not None and dep_date != today and has_return:
                    return f"Parking + {depot}" if depot else "Parking"

                # 3.3 – not today, no return → On Road
                if dep_date is not None and dep_date != today and not has_return:
                    return "On Road"

    return "N/A"


# ─────────────────────────────────────────────────────────────────────────────
# UI
# ─────────────────────────────────────────────────────────────────────────────

st.markdown("""
<div class="dashboard-header">
  <h1>🚛 Trailer Status Dashboard</h1>
  <p>ระบบตรวจสอบสถานะตู้รถอัตโนมัติ | Lotus / Linfox Fleet Management</p>
</div>
""", unsafe_allow_html=True)

# ── Sidebar : File Upload ────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## 📂 อัพโหลดไฟล์ Excel")
    st.markdown("---")

    st.markdown('<div class="upload-box"><h4>1️⃣ Trailer Lotus</h4>', unsafe_allow_html=True)
    f_lotus = st.file_uploader("ทะเบียนตู้รถทั้งหมด", type=["xlsx","xlsm"], key="lotus")
    st.markdown('</div>', unsafe_allow_html=True)

    st.markdown('<div class="upload-box"><h4>2️⃣ VOR Allnow</h4>', unsafe_allow_html=True)
    f_vor_all = st.file_uploader("ตู้ชำรุด / รอขาย (Allnow)", type=["xlsx","xlsm"], key="vor_all")
    st.markdown('</div>', unsafe_allow_html=True)

    st.markdown('<div class="upload-box"><h4>3️⃣ VOR Linfox</h4>', unsafe_allow_html=True)
    f_vor_lin = st.file_uploader("ตู้ชำรุด / รอขาย (Linfox)", type=["xlsx","xlsm"], key="vor_lin")
    st.markdown('</div>', unsafe_allow_html=True)

    st.markdown('<div class="upload-box"><h4>4️⃣ Trucker</h4>', unsafe_allow_html=True)
    f_trucker = st.file_uploader("ข้อมูล Trip", type=["xlsx","xlsm"], key="trucker")
    st.markdown('</div>', unsafe_allow_html=True)

    st.markdown("---")
    run_date = st.date_input("📅 วันที่ประมวลผล (Today)", value=date.today())
    run_btn  = st.button("▶️  ประมวลผล", use_container_width=True, type="primary")

# ── Main area ───────────────────────────────────────────────────────────────
if not run_btn:
    st.info("📌 กรุณาอัพโหลดไฟล์ Excel ทั้ง 4 ไฟล์ในแถบด้านซ้าย แล้วกด **ประมวลผล**")
    st.markdown("""
    ### วิธีการใช้งาน
    | ไฟล์ | รายละเอียด |
    |---|---|
    | **Trailer Lotus** | รายการป้ายทะเบียนตู้รถทั้งหมด (column: Fleet#) |
    | **VOR Allnow** | ตู้ชำรุด + รอขาย (sheet: VOR report, รอขาย) |
    | **VOR Linfox** | ตู้ชำรุด + รอขาย (sheet: วันที่ เช่น "10 Jun 26", Disposal Status) |
    | **Trucker** | Trip ประจำวัน (column: Trailer, Confirmed Depart/Return DC Time, Depart Depot) |

    ### สถานะที่แสดง
    - 🔴 **VOR** – ตู้รถชำรุด หรือ รอขาย
    - 🔵 **ชื่อ Depot** – ออกเดินทางวันนี้ ยังไม่กลับ
    - 🟡 **Parking + Depot** – กลับ Depot แล้ว
    - 🟢 **On Road** – อยู่ระหว่างเส้นทาง
    - ⚪ **N/A** – ไม่พบข้อมูล
    """)
    st.stop()

# ── Validate uploads ─────────────────────────────────────────────────────────
missing = []
if not f_lotus:   missing.append("Trailer Lotus")
if not f_vor_all: missing.append("VOR Allnow")
if not f_vor_lin: missing.append("VOR Linfox")
if not f_trucker: missing.append("Trucker")

if missing:
    st.error(f"❌ ยังไม่ได้อัพโหลดไฟล์: **{', '.join(missing)}**")
    st.stop()

# ── Load workbooks ────────────────────────────────────────────────────────────
with st.spinner("กำลังโหลดไฟล์ Excel ..."):
    try:
        wb_lotus   = read_excel_bytes(f_lotus)
        wb_vor_all = read_excel_bytes(f_vor_all)
        wb_vor_lin = read_excel_bytes(f_vor_lin)
        wb_trucker = read_excel_bytes(f_trucker)
    except Exception as e:
        st.error(f"❌ โหลดไฟล์ไม่สำเร็จ: {e}")
        st.stop()

# ── Read Trailer Lotus master list ───────────────────────────────────────────
with st.spinner("กำลังอ่านรายการตู้รถ ..."):
    lotus_sheet = wb_lotus.sheetnames[0]
    lotus_ws    = wb_lotus[lotus_sheet]
    hdr_row     = find_header_row(lotus_ws, "Fleet")
    data        = list(lotus_ws.values)

    if hdr_row >= len(data):
        st.error("❌ ไม่พบ header ในไฟล์ Trailer Lotus")
        st.stop()

    cols    = [str(c).strip() if c is not None else f"col_{i}" for i, c in enumerate(data[hdr_row])]
    rows    = data[hdr_row + 1:]
    lotus_df = pd.DataFrame(rows, columns=cols)

    fleet_col = find_col(lotus_df, ["Fleet#", "Fleet No", "Fleet Number", "Trailer", "Registration"])
    if fleet_col is None:
        st.error("❌ ไม่พบ column 'Fleet#' ใน Trailer Lotus (ลองตรวจสอบชื่อ column)")
        with st.expander("Columns ที่พบ"):
            st.write(lotus_df.columns.tolist())
        st.stop()

# ── Compute status for each trailer ──────────────────────────────────────────
today = run_date

progress = st.progress(0, text="กำลังประมวลผลสถานะตู้รถ ...")
statuses = []
total = len(lotus_df)

for i, val in enumerate(lotus_df[fleet_col]):
    status = get_status_for_trailer(val, wb_vor_all, wb_vor_lin, wb_trucker, today)
    statuses.append(status)
    if i % max(1, total // 50) == 0:
        progress.progress(int((i + 1) / total * 100), text=f"ประมวลผล {i+1}/{total} คัน ...")

progress.empty()

lotus_df["🚦 Status"] = statuses

# ── Summary metrics ───────────────────────────────────────────────────────────
vor_cnt     = sum(1 for s in statuses if s == "VOR")
dispose_cnt = sum(1 for s in statuses if s == "Dispose")
onroad_cnt  = sum(1 for s in statuses if s == "On Road")
parking_cnt = sum(1 for s in statuses if s.startswith("Parking"))
depot_cnt   = sum(1 for s in statuses if s not in ("VOR","Dispose","On Road","N/A") and not s.startswith("Parking"))
na_cnt      = sum(1 for s in statuses if s == "N/A")

col1, col2, col3, col4, col5, col6 = st.columns(6)

def metric_card(col, val, label, color):
    col.markdown(f"""
    <div class="metric-card" style="border-top-color:{color}">
      <div class="val" style="color:{color}">{val}</div>
      <div class="lbl">{label}</div>
    </div>""", unsafe_allow_html=True)

metric_card(col1, total,       "🚛 ตู้รถทั้งหมด",  "#1e3a5f")
metric_card(col2, vor_cnt,     "⚠️ VOR",            "#dc2626")
metric_card(col3, dispose_cnt, "🗑️ Dispose",        "#6b21a8")
metric_card(col4, depot_cnt,   "🏭 ออกเดินทาง",    "#2563eb")
metric_card(col5, parking_cnt, "🅿️ Parking",        "#d97706")
metric_card(col6, onroad_cnt,  "🟢 On Road",        "#16a34a")

st.markdown("<br>", unsafe_allow_html=True)

# ── Filter bar ────────────────────────────────────────────────────────────────
st.markdown("### 📋 รายการตู้รถทั้งหมด")

col_f1, col_f2 = st.columns([3, 1])
with col_f1:
    search_txt = st.text_input("🔍 ค้นหาป้ายทะเบียน", placeholder="เช่น 80-1234")
with col_f2:
    all_statuses = ["ทั้งหมด"] + sorted(set(statuses))
    filter_status = st.selectbox("กรองสถานะ", all_statuses)

display_df = lotus_df.copy()

if search_txt:
    mask = display_df[fleet_col].astype(str).str.upper().str.contains(search_txt.upper(), na=False)
    display_df = display_df[mask]

if filter_status != "ทั้งหมด":
    display_df = display_df[display_df["🚦 Status"] == filter_status]

# ── Build HTML table ──────────────────────────────────────────────────────────
def status_badge(s):
    return badge_html(s)

# Render using st.dataframe with color coding via pandas Styler
def style_status(val):
    color_map = {
        "VOR":      "background-color:#fee2e2; color:#991b1b; font-weight:700;",
        "Dispose":  "background-color:#f3e8ff; color:#6b21a8; font-weight:700;",
        "On Road":  "background-color:#dcfce7; color:#166534; font-weight:700;",
        "N/A":      "background-color:#f3f4f6; color:#6b7280;",
    }
    if val in color_map:
        return color_map[val]
    if str(val).startswith("Parking"):
        return "background-color:#fef9c3; color:#854d0e; font-weight:700;"
    return "background-color:#dbeafe; color:#1e40af; font-weight:700;"  # depot

styled = (
    display_df.style
    .applymap(style_status, subset=["🚦 Status"])
    .set_properties(**{"font-size": "13px"})
    .set_table_styles([
        {"selector": "thead th", "props": [
            ("background-color", "#1e3a5f"),
            ("color", "white"),
            ("font-size", "13px"),
            ("font-weight", "700"),
            ("padding", "10px 14px"),
        ]},
        {"selector": "tbody tr:nth-of-type(even)", "props": [("background-color", "#f8fafc")]},
        {"selector": "tbody td", "props": [("padding", "8px 14px")]},
    ])
)

st.dataframe(display_df, use_container_width=True, height=520)

# ── Legend ─────────────────────────────────────────────────────────────────────
with st.expander("📖 คำอธิบายสถานะ"):
    st.markdown("""
    | สถานะ | ความหมาย |
    |---|---|
    | ⚠️ **VOR** | ตู้รถชำรุด หรืออยู่ระหว่างรอขาย |
    | 🏭 **ชื่อ Depot** | ออกเดินทางวันนี้ ยังไม่มีเวลากลับ |
    | 🅿️ **Parking + Depot** | ออกเดินทางวันอื่น และมีการบันทึกเวลากลับแล้ว |
    | 🚛 **On Road** | ออกเดินทางวันอื่น แต่ยังไม่มีเวลากลับ (อยู่บนถนน) |
    | ⚪ **N/A** | ไม่พบข้อมูลในระบบ |
    """)

# ── Download ───────────────────────────────────────────────────────────────────
st.markdown("---")
export_df = display_df.copy()
output = io.BytesIO()
with pd.ExcelWriter(output, engine="openpyxl") as writer:
    export_df.to_excel(writer, index=False, sheet_name="Trailer Status")
output.seek(0)

st.download_button(
    label="⬇️ ดาวน์โหลดผลลัพธ์ (.xlsx)",
    data=output,
    file_name=f"trailer_status_{today.strftime('%Y%m%d')}.xlsx",
    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    use_container_width=True,
)

st.markdown(f"<p style='text-align:center;color:#9ca3af;font-size:.75rem;'>ประมวลผล ณ วันที่ {today.strftime('%d %B %Y')} | Trailer Status Dashboard v1.0</p>", unsafe_allow_html=True)
